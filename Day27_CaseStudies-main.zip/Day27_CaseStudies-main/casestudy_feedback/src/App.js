import React from "react";
import FeedbackForm from "./FeedbackForm";

function App() {
  return (
    <div>
      <h1>LMS Feedback Form</h1>
      <FeedbackForm />
    </div>
  );
}

export default App;
