
import './App.css';
import CS2 from './cs2';

function App() {
  return (
    <div className="App">
     <CS2 />
    </div>
  );
}

export default App;
