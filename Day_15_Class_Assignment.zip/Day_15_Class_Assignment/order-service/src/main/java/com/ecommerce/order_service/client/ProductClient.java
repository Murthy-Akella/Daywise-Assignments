package com.ecommerce.order_service.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import com.ecommerce.order_service.model.Product;

@FeignClient(name = "product-service")
public interface ProductClient {

    @GetMapping("/products/{id}")
    Product getProduct(@PathVariable("id") String id);

    @PutMapping("/products/{id}/reduceStock")
    Product reduceStock(@PathVariable("id") String id, @RequestParam("qty") int qty);
}
