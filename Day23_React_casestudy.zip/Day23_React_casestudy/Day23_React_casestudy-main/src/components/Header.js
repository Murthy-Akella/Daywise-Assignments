import React from 'react'

const Header = () => {
  return (
    <div>
        <h3>Header component</h3>
        </div>
  )
}

export default Header