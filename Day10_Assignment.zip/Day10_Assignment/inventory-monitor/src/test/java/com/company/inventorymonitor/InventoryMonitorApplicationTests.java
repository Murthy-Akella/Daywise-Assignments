package com.company.inventorymonitor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InventoryMonitorApplicationTests {

	@Test
	void contextLoads() {
	}

}
