package com.company.inventorymonitor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InventoryMonitorApplication {

	public static void main(String[] args) {
		SpringApplication.run(InventoryMonitorApplication.class, args);
	}

}
